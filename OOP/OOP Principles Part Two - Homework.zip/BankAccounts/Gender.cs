﻿namespace BankAccounts
{
    public enum Gender
    {
        Male,
        Female,
        SomethingElse,
        NikoletaLozanova
    }
}
