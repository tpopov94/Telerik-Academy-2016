﻿namespace BankAccounts
{
    public interface IWithdrawable
    {
        void WithdrawMoney(decimal amount);
    }
}
