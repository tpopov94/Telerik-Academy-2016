﻿namespace BankAccounts
{
    public interface IDepositable
    {
        void AddMoney(decimal amount);
    }
}
