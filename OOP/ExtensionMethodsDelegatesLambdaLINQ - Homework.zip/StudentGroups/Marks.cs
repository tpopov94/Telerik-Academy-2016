﻿namespace StudentGroups
{
    public enum Marks
    {
        Poor = 2, Average = 3, Good = 4, VeryGood = 5, Excellent = 6
    }
}
