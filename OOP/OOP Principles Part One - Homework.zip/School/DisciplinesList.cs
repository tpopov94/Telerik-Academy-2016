﻿namespace School
{
    public enum DisciplinesList
    {
        Mathematics, 
        English, 
        Russian, 
        Bulgarain, 
        French, 
        Deutch, 
        Chemistry, 
        History, 
        Geography, 
        Sports, 
        ComputerScience, 
        Arts,
        Physics
    }
}
