﻿namespace School
{
    using System.Collections.Generic;
    using System.Text;

    public interface IComment
    {
        void AddComment(string comment);
    }
}
