﻿namespace Animals
{
    public interface ISound
    {
        void MakeSound();
    }
}
