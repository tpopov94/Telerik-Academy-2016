﻿namespace Animals
{
    public enum Gender
    {
        Male,
        Female,
        Something
    }
}
