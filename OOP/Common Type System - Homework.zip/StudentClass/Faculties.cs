﻿namespace StudentClass
{
    public enum Faculties
    {
        Dental,
        Telecomunications,
        Electronics,
        InternationalRelationships,
        Football,
        Farmacy,
        ComputerScience
    }
}
