﻿namespace StudentClass
{
    public enum University
    {
        TU,
        SU,
        UNWE,
        NBU,
        NSA,
        MU
    }
}
