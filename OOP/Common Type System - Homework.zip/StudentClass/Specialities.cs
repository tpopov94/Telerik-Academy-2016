﻿namespace StudentClass
{
    public enum Specialities
    {
        ComputerScience,
        Tellecomunications,
        Law,
        History,
        Economics,
        Medicine,
        Farmacy,
        Electronics,
        Architecture
    }
}
